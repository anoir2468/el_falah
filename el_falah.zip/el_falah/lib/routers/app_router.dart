import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/common/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../screens/equipment/equipment_list_screen.dart';
import '../screens/workers/workers_list_screen.dart';
import '../screens/map/select_location_screen.dart';
import '../screens/messages/messages_screen.dart';
import '../screens/messages/chat_detail_screen.dart';
import '../screens/equipment/equipment_detail_screen.dart';
import '../screens/workers/worker_detail_screen.dart';

class AppRouter {
  static final router = GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(path: '/', builder: (c, s) => const SplashScreen()),
      GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
      GoRoute(path: '/register', builder: (c, s) => const RegisterScreen()),
      GoRoute(path: '/home', builder: (c, s) => const HomeScreen()),
      GoRoute(path: '/profile', builder: (c, s) => const ProfileScreen()),
      GoRoute(path: '/equipment', builder: (c, s) => const EquipmentListScreen()),
      GoRoute(path: '/workers', builder: (c, s) => const WorkersListScreen()),
      GoRoute(path: '/map', builder: (c, s) => const SelectLocationScreen()),
      GoRoute(path: '/messages', builder: (c, s) => const MessagesScreen()),
      GoRoute(path: '/chat/:chatId', builder: (c, s) {
        final id = s.params['chatId'] ?? '';
        return ChatDetailScreen(chatId: id);
      }),
      GoRoute(path: '/equipment/:id', builder: (c, s) {
        final id = s.params['id'] ?? '';
        return EquipmentDetailScreen(equipmentId: id);
      }),
      GoRoute(path: '/worker/:id', builder: (c, s) {
        final id = s.params['id'] ?? '';
        return WorkerDetailScreen(workerId: id);
      }),
    ],
  );
}
