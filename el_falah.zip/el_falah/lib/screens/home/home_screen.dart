import 'package:flutter/material.dart';
import '../../widgets/app_drawer.dart';
import '../../widgets/product_card.dart';
import 'package:go_router/go_router.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // TODO: replace with real data from FirestoreService
  final sampleProducts = [
    {'id': '1', 'title': 'جرار MF-410', 'image': '', 'price': '1,200,000 دج'},
    {'id': '2', 'title': 'حاصدة MF', 'image': '', 'price': '2,500,000 دج'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الفلاح الجزائري')),
      drawer: const AppDrawer(),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('أبحث عن...',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 0.75,
            children: sampleProducts
                .map((p) => ProductCard(
                      id: p['id']!,
                      title: p['title']!,
                      imageUrl: p['image']!.isEmpty
                          ? 'https://via.placeholder.com/400'
                          : p['image']!,
                      price: p['price']!,
                      onTap: () {
                        GoRouter.of(context).go('/equipment/${p['id']}');
                      },
                    ))
                .toList(),
          ),
        ],
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(children: [
          IconButton(
              icon: const Icon(Icons.home),
              onPressed: () => GoRouter.of(context).go('/home')),
          IconButton(
              icon: const Icon(Icons.build),
              onPressed: () => GoRouter.of(context).go('/equipment')),
          IconButton(
              icon: const Icon(Icons.people),
              onPressed: () => GoRouter.of(context).go('/workers')),
          IconButton(
              icon: const Icon(Icons.message),
              onPressed: () => GoRouter.of(context).go('/messages')),
        ]),
      ),
    );
  }
}
