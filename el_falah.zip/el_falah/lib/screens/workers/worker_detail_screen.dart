import 'package:flutter/material.dart';

class WorkerDetailScreen extends StatelessWidget {
  final String workerId;
  const WorkerDetailScreen({required this.workerId, super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل العامل')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Image.network('https://via.placeholder.com/400'),
            const SizedBox(height: 12),
            const Text('اسم العامل',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('التخصص: حرث\nالخبرة: 5 سنوات\nالسعر اليومي: 3000 دج'),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: () {}, child: const Text('طلب العامل')),
            const SizedBox(height: 8),
            ElevatedButton(
                onPressed: () {}, child: const Text('إضافة للمفضلة')),
          ],
        ),
      ),
    );
  }
}
