import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final chats = List.generate(
        6,
        (i) => {
              'id': 'chat_$i',
              'title': 'محادثة ${i + 1}',
              'last': 'رسالة أخيرة'
            });
    return Scaffold(
      appBar: AppBar(title: const Text('الرسائل')),
      body: ListView.separated(
        itemCount: chats.length,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (c, i) {
          final ch = chats[i];
          return ListTile(
            title: Text(ch['title']!),
            subtitle: Text(ch['last']!),
            onTap: () => GoRouter.of(context).go('/chat/${ch['id']}'),
          );
        },
      ),
    );
  }
}
