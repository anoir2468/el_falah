import 'package:flutter/material.dart';
import '../../services/firestore_service.dart';

class ChatDetailScreen extends StatefulWidget {
  final String chatId;
  const ChatDetailScreen({required this.chatId, super.key});
  @override
  State<ChatDetailScreen> createState() => _ChatDetailScreenState();
}

class _ChatDetailScreenState extends State<ChatDetailScreen> {
  final _ctrl = TextEditingController();
  final FirestoreService _fs = FirestoreService();

  void _send() async {
    if (_ctrl.text.trim().isEmpty) return;
    await _fs.sendMessage(widget.chatId, {
      'text': _ctrl.text.trim(),
      'from': 'me',
      'sentAt': DateTime.now().millisecondsSinceEpoch,
    });
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('محادثة')),
      body: Column(
        children: [
          Expanded(
            child: Center(
                child: Text(
                    'هنا ستعرض الرسائل (stream من Firestore)')), // future: implement stream builder
          ),
          SafeArea(
            child: Row(
              children: [
                Expanded(
                    child: TextField(
                        controller: _ctrl,
                        decoration:
                            const InputDecoration(hintText: 'اكتب رسالة...'))),
                IconButton(icon: const Icon(Icons.send), onPressed: _send),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
