import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class SelectLocationScreen extends StatefulWidget {
  const SelectLocationScreen({super.key});
  @override
  State<SelectLocationScreen> createState() => _SelectLocationScreenState();
}

class _SelectLocationScreenState extends State<SelectLocationScreen> {
  static final LatLng _center = LatLng(36.7538, 3.0588); // الجزائر العاصمة
  LatLng _picked = _center;
  GoogleMapController? _controller;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('اختر الموقع')),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(target: _center, zoom: 12),
        onMapCreated: (c) => _controller = c,
        onTap: (latLng) {
          setState(() => _picked = latLng);
        },
        markers: {_marker()},
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).pop(_picked),
        label: const Text('حفظ الموقع'),
        icon: const Icon(Icons.save),
      ),
    );
  }

  Marker _marker() =>
      Marker(markerId: const MarkerId('picked'), position: _picked);
}
