import 'package:flutter/material.dart';
import '../../widgets/location_selector.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  String wilaya = '', commune = '';

  void _save() {
    // TODO: save to Firestore
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('تم حفظ التغييرات')));
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تعديل الملف الشخصي')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView(children: [
          TextField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'الاسم')),
          const SizedBox(height: 8),
          TextField(
              controller: _phone,
              decoration: const InputDecoration(labelText: 'رقم الهاتف')),
          const SizedBox(height: 12),
          LocationSelector(onChanged: (w, c) {
            wilaya = w;
            commune = c;
          }),
          const SizedBox(height: 20),
          ElevatedButton(onPressed: _save, child: const Text('حفظ')),
        ]),
      ),
    );
  }
}
