import 'package:flutter/material.dart';
import '../../widgets/app_drawer.dart';
import 'edit_profile_screen.dart';
import 'package:go_router/go_router.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    // TODO: load current user from Firestore
    return Scaffold(
      appBar: AppBar(title: const Text('الملف الشخصي')),
      drawer: const AppDrawer(),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            CircleAvatar(
                radius: 48,
                backgroundImage:
                    NetworkImage('https://via.placeholder.com/200')),
            const SizedBox(height: 12),
            const Text('اسم المستخدم',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('البريد: user@example.com'),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: () => GoRouter.of(context).go('/profile/edit'),
                child: const Text('تعديل الملف')),
          ],
        ),
      ),
    );
  }
}
