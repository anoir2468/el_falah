import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class EquipmentDetailScreen extends StatelessWidget {
  final String equipmentId;
  const EquipmentDetailScreen({required this.equipmentId, super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: load details from Firestore
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل المعدة')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          Image.network('https://via.placeholder.com/800x400'),
          const SizedBox(height: 12),
          const Text('اسم المعدة',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('الوصف التفصيلي للمعدة...'),
          const SizedBox(height: 12),
          ElevatedButton(
              onPressed: () {}, child: const Text('التواصل مع البائع')),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: () {}, child: const Text('إضافة للمفضلة')),
        ],
      ),
    );
  }
}
