import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            DrawerHeader(
                child: Image.asset('assets/images/logo.png', height: 80)),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('الرئيسية'),
              onTap: () => GoRouter.of(context).go('/home'),
            ),
            ListTile(
              leading: const Icon(Icons.build),
              title: const Text('المعدات'),
              onTap: () => GoRouter.of(context).go('/equipment'),
            ),
            ListTile(
              leading: const Icon(Icons.people),
              title: const Text('العمال'),
              onTap: () => GoRouter.of(context).go('/workers'),
            ),
            ListTile(
              leading: const Icon(Icons.map),
              title: const Text('الخريطة'),
              onTap: () => GoRouter.of(context).go('/map'),
            ),
            const Spacer(),
            ListTile(
              leading: const Icon(Icons.logout),
              title: const Text('تسجيل الخروج'),
              onTap: () {
                // call sign out later
                GoRouter.of(context).go('/login');
              },
            ),
          ],
        ),
      ),
    );
  }
}
