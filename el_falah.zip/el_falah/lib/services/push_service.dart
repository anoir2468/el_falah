import 'package:firebase_messaging/firebase_messaging.dart';

class PushService {
  static Future<void> init() async {
    try {
      final fcm = FirebaseMessaging.instance;
      await fcm.requestPermission();
      final token = await fcm.getToken();
      print('FCM token: $token');

      FirebaseMessaging.onMessage.listen((message) {
        if (message.notification != null) {
          print('New message notification: ${message.notification!.title}');
        }
      });
    } catch (e) {
      print('Push init error: $e');
    }
  }
}
