import 'package:cloud_firestore/cloud_firestore.dart';
import '../utils/constants.dart';
import '../models/equipment_model.dart';
import '../models/worker_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Equipments
  Future<void> addEquipment(Equipment e) async {
    await _db.collection(Constants.EQUIPMENTS).doc(e.id).set(e.toMap());
  }

  Future<List<Equipment>> fetchEquipments() async {
    final snap = await _db.collection(Constants.EQUIPMENTS).get();
    return snap.docs.map((d) => Equipment.fromMap(d.data())).toList();
  }

  Future<Equipment?> getEquipment(String id) async {
    final doc = await _db.collection(Constants.EQUIPMENTS).doc(id).get();
    if (!doc.exists) return null;
    return Equipment.fromMap(doc.data()!);
  }

  // Workers
  Future<void> addWorker(WorkerModel w) async {
    await _db.collection(Constants.WORKERS).doc(w.id).set(w.toMap());
  }

  Future<List<WorkerModel>> fetchWorkers() async {
    final snap = await _db.collection(Constants.WORKERS).get();
    return snap.docs.map((d) => WorkerModel.fromMap(d.data())).toList();
  }

  Future<WorkerModel?> getWorker(String id) async {
    final doc = await _db.collection(Constants.WORKERS).doc(id).get();
    if (!doc.exists) return null;
    return WorkerModel.fromMap(doc.data()!);
  }

  // Chat (simple)
  Stream<QuerySnapshot> messagesStream(String chatId) {
    return _db
        .collection(Constants.CHATS)
        .doc(chatId)
        .collection(Constants.MESSAGES)
        .orderBy('sentAt', descending: false)
        .snapshots();
  }

  Future<void> sendMessage(String chatId, Map<String, dynamic> message) async {
    final col = _db
        .collection(Constants.CHATS)
        .doc(chatId)
        .collection(Constants.MESSAGES);
    await col.add(message);
  }
}
