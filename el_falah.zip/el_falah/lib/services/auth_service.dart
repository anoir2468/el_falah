import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<User?> signInWithEmail(String email, String password) async {
    final cred = await _auth.signInWithEmailAndPassword(
        email: email, password: password);
    return cred.user;
  }

  Future<User?> registerWithEmail(String name, String email, String password,
      String phone, String role) async {
    final cred = await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    final user = cred.user!;
    // save user data in Firestore
    final model = AppUser(
      uid: user.uid,
      name: name,
      email: email,
      phone: phone,
      role: role,
      photoUrl: '',
      wilaya: '',
      commune: '',
    );
    await _firestore
        .collection(Constants.USERS)
        .doc(user.uid)
        .set(model.toMap());
    return user;
  }

  Future<void> signOut() async {
    await _auth.signOut();
  }

  Future<void> resetPassword(String email) async {
    await _auth.sendPasswordResetEmail(email: email);
  }

  Stream<User?> authStateChanges() => _auth.authStateChanges();
}
